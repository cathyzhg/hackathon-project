Habitat metrics — 2010 vs 2020 (separate graphs)
================================================
Files:
  - index.html
  - data.csv

Run locally (recommended):
  cd habitat_2010_2020_graphs
  python -m http.server 8000
  open http://localhost:8000/habitat_2010_2020_graphs/

Edit data:
  - Open data.csv and replace numbers with your real 2010 and 2020 values.
  - Refresh the page.

HVI:
  - Uses min–max normalization across all rows in data.csv
  - Higher is better: TreeCanopyPct
  - Lower is better: PopDensityPerSqMi, BuildingCoveragePct, RoadCoveragePct
  - Missing values are skipped and remaining weights renormalize
